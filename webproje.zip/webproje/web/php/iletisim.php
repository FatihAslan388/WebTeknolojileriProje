<meta charset="utf-8">
Ad: <?php echo $_POST['firstname'];?> <br>
Soyad : <?php echo $_POST['lastname'] ?> <br>
Cinsiyet : <?php echo $_POST['gender'] ?> <br>
Yaş : <?php echo $_POST['yas'] ?> <br>
E-Mail : <?php echo $_POST['email'] ?> <br>
Tel Tür : <?php echo $_POST['tip'] ?> <br>
Tel No : <?php echo $_POST['tel'] ?> <br>
Mesajınız : <?php echo $_POST['messeage'] ?> <br>